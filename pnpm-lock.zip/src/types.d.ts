export type IconColor = 'white' | 'black';
export type IconClassName = 'newtab-btn' | 'download-btn';
